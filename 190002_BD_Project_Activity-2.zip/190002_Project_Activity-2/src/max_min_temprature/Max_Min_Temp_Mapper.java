package max_min_temprature;
import java.io.IOException;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
public class Max_Min_Temp_Mapper extends
Mapper<LongWritable, Text, Text, Text>{
	// the data in our data set with
    // this value is inconsistent data
 
          
    @Override
        public void map(LongWritable arg0, Text Value, Context context)
                throws IOException, InterruptedException {
  
        // Convert the single row(Record) to 
        // String and store it in String
        // variable name line
              
        String line = Value.toString();
              
            // Check for the empty line
            if (!(line.length() == 0)) {
                  
                // from character 6 to 14 we have
                // the date in our dataset
                String date = line.substring(6, 14);
  
                // similarly we have taken the maximum 
                // temperature from 39 to 45 characters
                float temp_Max = Float.parseFloat(line.substring(39, 45).trim());
                  
                // similarly we have taken the minimum 
                // temperature from 47 to 53 characters
                  
                float temp_Min = Float.parseFloat(line.substring(47, 53).trim());
  
                // if maximum temperature is
                // greater than 30, it is a hot day
                if (temp_Max > 30.0) {
                      
                    // Hot day
                    context.write(new Text("Maximum Temprature:" + date),
                                         new Text(String.valueOf(temp_Max)));
                }
  
                // if the minimum temperature is 
                // less than 15, it is a cold day
                if (temp_Min < 15) {
                      
                    // Cold day
                    context.write(new Text("Minimum Temprature :" + date),
                            new Text(String.valueOf(temp_Min)));
                }
            }
            
    }
}
