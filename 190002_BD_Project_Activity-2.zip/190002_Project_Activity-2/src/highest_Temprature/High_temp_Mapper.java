package highest_Temprature;
import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
public class High_temp_Mapper extends Mapper<LongWritable, Text, Text, Text>{

	    @Override
	        public void map(LongWritable arg0, Text Value, Context context)
	                throws IOException, InterruptedException {
	    	String line = Value.toString();
         
         // Check for the empty line
         if (!(line.length() == 0)) {
               
             // from character 6 to 10 we have
             // the year in our dataset
            String year = line.substring(6, 10);

             // similarly we have taken the avg temp 
             // temperature from 63 to 69 characters
             float temp_avg = Float.parseFloat(line.substring(63, 69).trim());
               
     
            
             // if maximum temperature is
             // greater than 35, it is a hot day
             if (temp_avg > 35) {
                   
                 // Hot day
                 context.write(new Text("Highestt Temprature :" + year),
                                      new Text(String.valueOf(temp_avg)));
             }

          
         }
     }
}
