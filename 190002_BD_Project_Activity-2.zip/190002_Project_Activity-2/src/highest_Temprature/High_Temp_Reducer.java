package highest_Temprature;
import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
public class High_Temp_Reducer extends
Reducer<Text, Text, Text, Text>{
	
	   
    public void reduce(Text Key, Iterable<Text> Values, Context context)
            throws IOException, InterruptedException {

    	String max= "0"; 
        // putting all the values in 
        // temperature variable of type String
    	for (Text value: Values){
    	String f = value.toString();
        if(f.compareTo(max)>0){
        	max=f;
        }
        	
        }
        context.write(Key, new Text(max));
    }
    
}
