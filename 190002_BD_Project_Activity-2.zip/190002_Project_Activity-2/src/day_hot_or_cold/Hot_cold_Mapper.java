package day_hot_or_cold;
import java.io.IOException;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
public class Hot_cold_Mapper extends Mapper<LongWritable, Text, Text, Text>{

	 public static final int MISSING = 9999;
     
	    @Override
	        public void map(LongWritable arg0, Text Value, Context context)
	                throws IOException, InterruptedException {
	    	String line = Value.toString();
            
            // Check for the empty line
            if (!(line.length() == 0)) {
                  
                // from character 6 to 14 we have
                // the date in our dataset
                String date = line.substring(6, 14);
  
                // similarly we have taken the maximum 
                // temperature from 39 to 45 characters
                float temp_avg = Float.parseFloat(line.substring(63, 69).trim());
                  
                // similarly we have taken the minimum 
                // temperature from 47 to 53 characters
               
                // if maximum temperature is
                // greater than 30, it is a hot day
                if (temp_avg > 35) {
                      
                    // Hot day
                    context.write(new Text("Maximum Temprature :" + date),
                                         new Text(String.valueOf(temp_avg)));
                }
  
                // if the minimum temperature is 
                // less than 15, it is a cold day
                if (temp_avg < 10) {
                      
                    // Cold day
                    context.write(new Text("Minimum Temprature :" + date),
                            new Text(String.valueOf(temp_avg)));
                }
            }
        }
}
