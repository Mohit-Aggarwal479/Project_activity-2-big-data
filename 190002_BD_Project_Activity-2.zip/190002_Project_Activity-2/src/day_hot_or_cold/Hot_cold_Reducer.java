package day_hot_or_cold;
import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
public class Hot_cold_Reducer extends
Reducer<Text, Text, Text, Text>{

	   
    public void reduce(Text Key, Iterator<Text> Values, Context context)
            throws IOException, InterruptedException {

          
        // putting all the values in 
        // temperature variable of type String
        String temperature = Values.next().toString();
        context.write(Key, new Text(temperature));
    }
}
