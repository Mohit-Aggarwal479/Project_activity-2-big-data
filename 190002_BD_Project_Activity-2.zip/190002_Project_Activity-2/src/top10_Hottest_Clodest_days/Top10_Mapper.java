package top10_Hottest_Clodest_days;
import java.io.IOException;
import java.util.Map;
import java.util.TreeMap;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
public class Top10_Mapper extends Mapper<LongWritable, Text, Text, Text>{

	public TreeMap<Text, Text> hotmap, coldmap;
	@Override
	public void setup(Context context) throws IOException, InterruptedException
	{
		hotmap = new TreeMap<Text, Text> ();
		coldmap = new TreeMap<Text, Text> ();
	}
    public void map(LongWritable key, Text value, Context con)
            throws IOException, InterruptedException {
	String line = value.toString();
    
    // Check for the empty line
    if (!(line.length() == 0)) {
          
        // from character 6 to 14 we have
        // the date in our dataset
        String date = line.substring(6, 14);

        
        
          
        // similarly we have taken the minimum 
        // temperature from 39 to 45 characters
        double coldtemp = Double.parseDouble(line.substring(39,45).trim());
        // temperature from 47 to 53 characters
        double hottemp = Double.parseDouble(line.substring(47,53).trim());
       
        // if maximum temperature is
        // greater than 30, it is a hot day
        if (hottemp > 35) {
              
        	Text text = new Text(date+" Top hotest temp of data ");
        	hotmap.put(text, new Text(String.valueOf(coldtemp)));
        	if(hotmap.size()>10)
        	{
        		hotmap.remove(hotmap.lastKey());
        	}
        }

        // if the minimum temperature is 
        // less than 15, it is a cold day
        if (coldtemp < 10) {
              
        	Text text = new Text(date+" Top coldest temp of data ");
        	coldmap.put(text, new Text(String.valueOf(coldtemp)));
        	if(coldmap.size()>10)
        	{
        		coldmap.remove(coldmap.lastKey());
        	}
        }
    }
    

}
    
    @Override
    public void cleanup(Context context) throws IOException, InterruptedException
    {
    	for (Map.Entry<Text, Text> entry : hotmap.entrySet())
    	{
    		Text words = entry.getKey();
    		Text count = entry.getValue();
    		context.write(words, count);
    	}
    	for (Map.Entry<Text, Text> entry : coldmap.entrySet())
    	{
    		Text words = entry.getKey();
    		Text count = entry.getValue();
    		context.write(words, count);
    	}
    }
}
