package top10_Hottest_Clodest_days;
import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class Top10_Reducer extends
Reducer<Text, Text, Text, Text>{
	

    public void reduce(Text word, Text values, Context con)
            throws IOException, InterruptedException {

        con.write(word, values);
    }
}
